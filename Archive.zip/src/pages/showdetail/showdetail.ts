import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-showdetail',
  templateUrl: 'showdetail.html',
})
export class ShowdetailPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }
}
