import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ShowdetailPage } from './showdetail';

@NgModule({
  declarations: [
    ShowdetailPage,
  ],
  imports: [
    IonicPageModule.forChild(ShowdetailPage),
  ],
})
export class ShowdetailPageModule {}
