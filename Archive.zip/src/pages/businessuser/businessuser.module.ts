import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BusinessuserPage } from './businessuser';

@NgModule({
  declarations: [
    BusinessuserPage,
  ],
  imports: [
    IonicPageModule.forChild(BusinessuserPage),
  ],
})
export class BusinessuserPageModule {}